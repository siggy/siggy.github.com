/* NVTV Intel 810 CRTC data header -- Dirk Thierbach <dthierbach@gmx.de>
 *
 * This file is part of nvtv, a tool for tv-output on NVidia cards.
 * 
 * nvtv is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * nvtv is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
 *
 * $Id: data_i810.h,v 1.4 2003/10/15 10:57:58 dthierbach Exp $
 *
 * Contents:
 *
 * Header: Data routines for the Intel 810 CRTC data.
 *
 */

#ifndef _DATA_I810_H
#define _DATA_I810_H

#include "tv_chip.h"
#include "data.h"

void data_init_i810 (TVI810Regs *r, int portHost);

extern DataCardFunc data_i810_func;

extern DataFunc data_i810_ch1_func;
extern DataFunc data_i810_ch2_func;

#endif /* _DATA_I810_H */
