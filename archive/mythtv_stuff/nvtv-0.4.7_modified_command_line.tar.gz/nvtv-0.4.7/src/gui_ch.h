/* NVTV GUI (Chrontel part) header -- Dirk Thierbach <dthierbach@gmx.de>
 *
 * This file is part of nvtv, a tool for tv-output on NVidia cards.
 * 
 * nvtv is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * nvtv is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
 *
 * $Id: gui_ch.h,v 1.5 2003/02/21 17:03:06 dthierbach Exp $
 *
 * Contents:
 *
 * Header: The GTK graphical user interface. Chrontel part.
 */

#ifndef _GUI_CH_H
#define _GUI_CH_H

#include "debug.h"
#include "gui.h"
#include "nv_type.h"

GtkWidget *gui_ch_reg1_page (void);
GtkWidget *gui_ch_reg2_page (void);
GtkWidget *gui_ch_status_page (void);

void gui_ch_init (void);

#endif /* _GUI_CH_H */
