/* NVTV GUI (Philips part) header -- Dirk Thierbach <dthierbach@gmx.de>
 *
 * This file is part of nvtv, a tool for tv-output on NVidia cards.
 * 
 * nvtv is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * nvtv is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
 *
 * $Id: gui_ph.h,v 1.9 2003/02/05 22:39:08 dthierbach Exp $
 *
 * Contents:
 *
 * Header: The GTK graphical user interface. Philips part.
 */

#ifndef _GUI_PH_H
#define _GUI_PH_H

#include "debug.h"
#include "gui.h"
#include "nv_type.h"

GtkWidget *gui_ph1_reg1_page (void);
GtkWidget *gui_ph1_reg2_page (void);
GtkWidget *gui_ph2_reg1_page (void);
GtkWidget *gui_ph2_reg2_page (void);
GtkWidget *gui_ph_status_page (void);
GtkWidget *gui_ph_calc_page (void);

void gui_ph_init (void);

#endif /* _GUI_PH_H */


