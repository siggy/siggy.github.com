/* Hack to be able to use xf86PciInfo.h unmodified */

typedef struct {
    int			token;		/* id of the token */
    const char *	name;		/* token name */
} SymTabRec, *SymTabPtr;

