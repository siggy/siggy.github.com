/* NVTV server -- Dirk Thierbach <dthierbach@gmx.de>
 *
 * This file is part of nvtv, a tool for tv-output on NVidia cards.
 * 
 * nvtv is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * nvtv is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
 *
 * $Id: nvtvd.c,v 1.4 2004/03/01 21:08:10 dthierbach Exp $
 *
 * Contents:
 *
 * Server main program
 *
 */

#include "local.h" /* before everything else */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <syslog.h>
#include <getopt.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#ifdef HAVE_SYS_STAT_H
#include <sys/stat.h>
#endif
#ifdef HAVE_SYS_TYPES_H
#include <sys/types.h>
#endif

#include "pipe.h"
#include "backend.h"
#include "back_unix.h"
#include "back_null.h"

/* -------- Options -------- */

BackAccessPtr back_access = NULL;  /* global backend */
BackCardPtr back_card = NULL;

Bool opt_null  = FALSE;
Bool opt_nvdev = FALSE;
Bool opt_debug = FALSE;
Bool opt_quiet = FALSE;

static const char *short_options = "?hnNdq";

static struct option long_options[] =
  {{"help",        no_argument,       NULL, 'h'},
   {"null",        no_argument,       NULL, 'n'},
   {"nvdev",       no_argument,       NULL, 'N'},
   {"debug",       no_argument,       NULL, 'd'},
   {"quiet",       no_argument,       NULL, 'q'},
   {NULL,          0,                 NULL, 0}
};

char *prog; /* Program name for error messages */
   
/* -------- Usage -------- */

void usage (void)
{
  fprintf (stderr,
      "usage: nvtvd [-options ...]\n\n");
  fprintf (stderr,
      "where options include:\n");
  fprintf (stderr,
      "  -h --help           print this message\n");
  fprintf (stderr,
      "  -N --nvdev          enable usage of /dev/nv* devices\n");
  fprintf (stderr,
      "  -n --null           use null backend (for debugging)\n");
  fprintf (stderr,
      "  -d --debug          don't detach from controlling terminal\n");
  fprintf (stderr,
      "  -q --quiet          no logging\n");
}

/* -------- Error handling -------- */

void raise_msg (int class, char *format, ...)
{
  static char buf[1024];
  static int pos = 0;
  int delta;
  va_list args;

  if (!opt_quiet) {
    va_start(args, format);
    delta = vsnprintf(buf + pos, sizeof(buf) - pos, format, args);
    va_end(args);
    if (delta == -1 || pos + delta > sizeof(buf) - 1) {
      pos = sizeof(buf);
    } else {
      pos += delta;
    }
    if (class == MSG_DEBUG_NL) return;
    pos = 0;
    if (opt_debug) {
      switch (class) {
	case MSG_ABORT:
	  fprintf (stderr, "Fatal: ");
	  break;
	case MSG_WARNING:
	  fprintf (stderr, "Warning: ");
	  break;
      }
      fprintf (stderr, "%s\n", buf);
    } else {
      switch (class) {
	case MSG_ABORT:
	  syslog (LOG_CRIT, "%.500s", buf);
	  break;
	case MSG_WARNING:
	  syslog (LOG_WARNING, "%.500s", buf);
	  break;
	case MSG_INFO:
	  syslog (LOG_INFO, "%.500s", buf);
	  break;
	case MSG_DEBUG:
	  syslog (LOG_DEBUG, "%.500s", buf);
	  break;
	default:
	case MSG_ERROR:
	  syslog (LOG_ERR, "%.500s", buf);
	  break;
      }
    }
  }
  if (class == MSG_ABORT) exit (1);
  /* FIXME */
}

/* -------- Server state -------- */

static CardPtr srv_root = NULL;
static CardPtr srv_card = NULL;

static FILE *pipe_in = NULL;
static FILE *pipe_out = NULL;

/* -------- Server command routines -------- */

void srv_openCard (void)
{
  CardPtr card;
  int i, index;

  RAISE (MSG_DEBUG, "srv_open");
  index = 0;
  pipeReadArgs (pipe_in, 1, sizeof(index), &index);
  /* convert index to card */
  card = srv_root;
  for (i = 1; i < index; i++) {
    if (card) card = card->next;
  }
  if (index == 0) card = NULL;
  srv_card = card;
  back_access->openCard (srv_card);
  pipeWriteCmd (pipe_out, PCmd_OpenCard);
  if (srv_card) {
    pipeWriteList (pipe_out, sizeof (ChipInfo), srv_card->chips);
  } else {
    pipeWriteArgs (pipe_out, 0);
  }
}

void srv_closeCard (void)
{
  RAISE (MSG_DEBUG, "srv_close");
  pipeReadArgs (pipe_in, 0);
  if (srv_card) {
    back_access->closeCard ();
  }
  srv_card = NULL;
}

void srv_setHeads (void)
{
  int monitor, tv, video;

  RAISE (MSG_DEBUG, "srv_setHeads");
  pipeReadArgs (pipe_in, 3, sizeof(int), &monitor, sizeof(int), &tv, 
		sizeof(int), &video);
  RAISE (MSG_DEBUG, "srv_setHeads %i %i %i", monitor, tv, video);
  back_card->setHeads (monitor, tv, video);
}

void srv_getHeads (void)
{
  int tv, monitor, video, max;

  RAISE (MSG_DEBUG, "srv_getHeads");
  pipeReadArgs (pipe_in, 0);
  back_card->getHeads (&monitor, &tv, &video, &max);
  RAISE (MSG_DEBUG, "srv_getHeads %i %i %i %i", monitor, tv, video, max);
  pipeWriteCmd (pipe_out, PCmd_GetHeads);
  pipeWriteArgs (pipe_out, 4, sizeof(int), &monitor, sizeof(int), &tv, 
		sizeof(int), &video, sizeof(int), &max);
}

void srv_getHeadDev (void)
{
  int head, devFlags;

  RAISE (MSG_DEBUG, "srv_getHeadDev");
  pipeReadArgs (pipe_in, 1, sizeof(int), &head);
  back_card->getHeadDev (head, &devFlags);
  RAISE (MSG_DEBUG, "srv_getHeadDev %i %i", head, devFlags);
  pipeWriteCmd (pipe_out, PCmd_GetHeadDev);
  pipeWriteArgs (pipe_out, 1, sizeof(int), &devFlags);
}

void srv_probeChips (void)
{
  RAISE (MSG_DEBUG, "srv_probe");
  pipeReadArgs (pipe_in, 0);
  back_card->probeChips ();
  pipeWriteCmd (pipe_out, PCmd_ProbeChips);
  pipeWriteList (pipe_out, sizeof (ChipInfo), srv_card->chips);
}

void srv_setChip (void)
{
  ChipPtr chip;
  Bool init;
  int i, index;

  RAISE (MSG_DEBUG, "srv_setChip");
  index = 0;
  init = 1;
  pipeReadArgs (pipe_in, 2, sizeof(index), &index, sizeof(init), &init);
  /* convert index to chip */
  chip = srv_card->chips;
  for (i = 1; i < index; i++) {
    if (chip) chip = chip->next;
  }
  if (index == 0) chip = NULL;
  back_card->setChip (chip, init);
}

void srv_setSettings (void)
{
  TVSettings set, *pset;

  RAISE (MSG_DEBUG, "srv_setSettings");
  pipeReadArgsOpt (pipe_in, 1, sizeof(TVSettings), &set, &pset);
  back_card->setSettings (pset);
}

void srv_getSettings (void)
{
  TVSettings set;

  RAISE (MSG_DEBUG, "srv_getSettings");
  pipeReadArgs (pipe_in, 0);
  back_card->getSettings (&set);
  pipeWriteCmd (pipe_out, PCmd_GetSettings);
  pipeWriteArgs (pipe_out, 1, sizeof(TVSettings), &set);
}

void srv_setMode (void)
{
  TVRegs regs, *pregs;

  RAISE (MSG_DEBUG, "srv_setMode");
  pipeReadArgsOpt (pipe_in, 1, sizeof(TVRegs), &regs, &pregs);
  back_card->setMode (pregs);
}

void srv_getMode (void)
{
  TVRegs regs;

  RAISE (MSG_DEBUG, "srv_getMode");
  pipeReadArgs (pipe_in, 0);
  back_card->getMode (&regs);
  pipeWriteCmd (pipe_out, PCmd_GetMode);
  pipeWriteArgs (pipe_out, 1, sizeof(TVRegs), &regs);
}

void srv_setModeSettings (void)
{
  TVRegs regs, *pregs;
  TVSettings set, *pset;

  RAISE (MSG_DEBUG, "srv_setModeSettings");
  pipeReadArgsOpt (pipe_in, 2, sizeof(TVRegs), &regs, &pregs, 
		   sizeof(TVSettings), &set, &pset);
  back_card->setModeSettings (pregs, pset);
}

void srv_setTestImage (void)
{
  TVEncoderRegs tv, *ptv;
  TVSettings set, *pset;

  RAISE (MSG_DEBUG, "srv_setTestImage");
  pipeReadArgsOpt (pipe_in, 2, sizeof(TVEncoderRegs), &tv, &ptv, 
		   sizeof(TVSettings), &set, &pset);
  back_card->setTestImage (ptv, pset);
}

void srv_getStatus (void)
{
  int index;
  long l;

  RAISE (MSG_DEBUG, "srv_getStatus");
  index = 0;
  pipeReadArgs (pipe_in, 1, sizeof(index), &index);
  pipeWriteCmd (pipe_out, PCmd_GetStatus);
  l = back_card->getStatus (index);
  pipeWriteArgs (pipe_out, 1, sizeof(l), &l);
}

void srv_getConnection (void)
{
  TVConnect c;

  RAISE (MSG_DEBUG, "srv_getConnection");
  pipeReadArgs (pipe_in, 0);
  pipeWriteCmd (pipe_out, PCmd_GetConnection);
  c = back_card->getConnection ();
  pipeWriteArgs (pipe_out, 1, sizeof(c), &c);
}

void srv_listModes (void)
{
  TVSystem system;
  TVMode *m, *modes; 
  int c;

  RAISE (MSG_DEBUG, "srv_findBySize");
  pipeReadArgs (pipe_in, 1, sizeof(system), &system);
  pipeWriteCmd (pipe_out, PCmd_ListModes);
  c = back_card->listModes (system, &modes);
  pipeWriteArray (pipe_out, c, 3);
  for (m = modes; c > 0; m++, c--) {
    pipeWriteArgs (pipe_out, 3, sizeof(TVMode), m, 
		   strlen (m->spec.size)+1, m->spec.size,
		   strlen (m->spec.aspect)+1, m->spec.aspect);
  }
}

void srv_findBySize (void)
{
  TVSystem system;
  int xres, yres;
  char *size;
  TVMode mode; 

  RAISE (MSG_DEBUG, "srv_findBySize");
  pipeReadArgs (pipe_in, 4, sizeof(system), &system, 
		sizeof(xres), &xres, sizeof(yres), &yres, 0, &size);
  pipeWriteCmd (pipe_out, PCmd_FindBySize);
  if (back_card->findBySize (system, xres, yres, size, &mode)) {
    pipeWriteArgs (pipe_out, 3, sizeof(TVMode), &mode, 
		   strlen (mode.spec.size)+1, mode.spec.size,
		   strlen (mode.spec.aspect)+1, mode.spec.aspect);
  } else {
    pipeWriteArgs (pipe_out, 0);
  }
}

void srv_findByOverscan (void)
{
  TVSystem system;
  int xres, yres;
  double hoc, voc;
  TVMode mode; 

  RAISE (MSG_DEBUG, "srv_findByOC");
  pipeReadArgs (pipe_in, 5, sizeof(system), &system, 
		 sizeof(xres), &xres, sizeof(yres), &yres,
		 sizeof(hoc), &hoc, sizeof(voc), &voc);
  pipeWriteCmd (pipe_out, PCmd_FindByOverscan);
  if (back_card->findByOverscan (system, xres, yres, hoc, voc, &mode)) 
  {
    pipeWriteArgs (pipe_out, 3, sizeof(TVMode), &mode, 
		   strlen (mode.spec.size)+1, mode.spec.size,
		   strlen (mode.spec.aspect)+1, mode.spec.aspect);
  } else {
    pipeWriteArgs (pipe_out, 0);
  }
}

void srv_initSharedView (void)
{
  int view_x, view_y;

  RAISE (MSG_DEBUG, "srv_initSharedView");
  pipeReadArgs (pipe_in, 0);
  back_card->initSharedView (&view_x, &view_y);
  pipeWriteCmd (pipe_out, PCmd_InitSharedView);
  pipeWriteArgs (pipe_out, 2, sizeof(int), &view_x, sizeof(int), &view_y);
}

void srv_getTwinView (void)
{
  int view_x, view_y;
  Bool result;

  RAISE (MSG_DEBUG, "srv_getTwinView");
  pipeReadArgs (pipe_in, 0);
  result = back_card->getTwinView (&view_x, &view_y);
  pipeWriteCmd (pipe_out, PCmd_GetTwinView);
  pipeWriteArgs (pipe_out, 3, sizeof(Bool), &result,
		sizeof(int), &view_x, sizeof(int), &view_y);
}

void srv_adjustViewport (void)
{
  int flags;
  int view_x, view_y;
  Bool result;

  RAISE (MSG_DEBUG, "srv_adjustViewport");
  pipeReadArgs (pipe_in, 3, sizeof(int), &flags, 
		 sizeof(int), &view_x, sizeof(int), &view_y);
  result = back_card->adjustViewport (flags, &view_x, &view_y);
  pipeWriteCmd (pipe_out, PCmd_AdjustView);
  pipeWriteArgs (pipe_in, 3, sizeof(int), &result, 
		sizeof(int), &view_x, sizeof(int), &view_y);
}

void srv_serviceViewportCursor (void)
{
  int flags;
  int cursor_x, cursor_y;
  int view_x, view_y;
  Bool result;

  RAISE (MSG_DEBUG, "srv_serviceViewportCursor");
  pipeReadArgs (pipe_in, 5, sizeof(int), &flags, 
		 sizeof(int), &cursor_x, sizeof(int), &cursor_y, 
		 sizeof(int), &view_x, sizeof(int), &view_y);
  result = back_card->serviceViewportCursor (flags, 
    cursor_x, cursor_y, &view_x, &view_y);
  pipeWriteCmd (pipe_out, PCmd_ServiceVC);
  pipeWriteArgs (pipe_in, 3, sizeof(int), &result, 
		sizeof(int), &view_x, sizeof(int), &view_y);
}

/* -------- -------- */

void srv_version (void)
{
  int version = PIPE_VERSION;

  pipeReadArgs (pipe_in, 0);
  pipeWriteCmd (pipe_out, PCmd_Version);
  pipeWriteArgs (pipe_out, 1, sizeof(version), &version);
}

void srv_init (void)
{
  RAISE (MSG_INFO, "init by client");
  pipeReadArgs (pipe_in, 0);
  if (srv_card) {
    back_card->closeCard ();
  }
  srv_card = NULL;
  pipeWriteCmd (pipe_in, PCmd_Init);
  pipeWriteList (pipe_out, sizeof (CardInfo), srv_root);
}


void srv_kill (void)
{
  pipeReadArgs (pipe_in, 0);
  sleep (1);
  /* FIXME */
}

void srv_openPipes (void)
{
  /* IMPORTANT: PIPE_OUT is open first for reading (and thus is
     pipe_in for the server). The open blocks until someone is writing
     to the pipe. */

  if (!pipe_in) {
    RAISE (MSG_DEBUG, "open in pipe");
    pipe_in  = fopen (PIPE_OUT, "r");
  }
  if (!pipe_in) {
    unlink (PIPE_OUT);
    unlink (PIPE_IN);
    RAISE (MSG_ABORT, "Cannot open pipe %s", prog, PIPE_OUT);
  }
  RAISE (MSG_DEBUG, "in pipe opened");

  /* Now open the other pipe for writing. */

  if (!pipe_out) {
    RAISE (MSG_DEBUG, "open out pipe");
    pipe_out = fopen (PIPE_IN, "w");
  }
  if (!pipe_out) {
    unlink (PIPE_OUT);
    unlink (PIPE_IN);
    RAISE (MSG_ABORT, "Cannot open pipe %s", prog, PIPE_IN);
  }
  RAISE (MSG_DEBUG, "out pipe opened");
}

void srv_closePipes ()
{
  RAISE (MSG_DEBUG, "close pipes");
  fclose (pipe_in);
  fclose (pipe_out);
  pipe_in = NULL;
  pipe_out = NULL;
}

void srv_loop (void) 
{
  PipeCmd cmd;

  while (TRUE) {
    srv_openPipes ();
    RAISE (MSG_DEBUG, "srv_loop read cmd (eof %i)", feof (pipe_in));
    cmd = pipeReadCmd (pipe_in);
    RAISE (MSG_DEBUG, "srv_loop %i (eof %i)", cmd, feof (pipe_in));
    if (feof (pipe_in)) srv_closePipes ();
    if (!pipe_in || !pipe_out) continue;
    switch (cmd) {
      case PCmd_Init:
	srv_init ();
	break;
      case PCmd_Kill:
	srv_kill ();
	break;
      case PCmd_Version:
	srv_version ();
	break;
      case PCmd_OpenCard:
	srv_openCard ();
	break;
      case PCmd_CloseCard:
	srv_closeCard ();
	break;
      case PCmd_SetHeads:
	srv_setHeads ();
	break;
      case PCmd_GetHeads:
	srv_getHeads ();
	break;
      case PCmd_GetHeadDev:
	srv_getHeadDev ();
	break;
      case PCmd_ProbeChips:
	srv_probeChips ();
	break;
      case PCmd_SetChip:
	srv_setChip ();
	break;
      case PCmd_SetSettings:
	srv_setSettings ();
	break;
      case PCmd_GetSettings:
	srv_getSettings ();
	break;
      case PCmd_SetMode:
	srv_setMode ();
	break;
      case PCmd_GetMode:
	srv_getMode ();
	break;
      case PCmd_SetModeSettings:
	srv_setModeSettings ();
	break;
      case PCmd_SetTestImage:
	srv_setTestImage ();
	break;
      case PCmd_GetStatus:
	srv_getStatus ();
	break;
      case PCmd_GetConnection:
	srv_getConnection ();
	break;
      case PCmd_ListModes:
	srv_listModes ();
	break;
      case PCmd_FindBySize:
	srv_findBySize ();
	break;
      case PCmd_FindByOverscan:
	srv_findByOverscan ();
	break;
      case PCmd_InitSharedView:
	srv_initSharedView ();
	break;
      case PCmd_GetTwinView:
	srv_getTwinView ();
	break;
      case PCmd_AdjustView:
	srv_adjustViewport ();
	break;
      case PCmd_ServiceVC:
	srv_serviceViewportCursor ();
	break;
      default: /* not understood, but have to clean up pipe */
	pipeReadArgs (pipe_in, 0);
	if (cmd & 1) {
	  pipeWriteCmd (pipe_out, cmd);
	  pipeWriteArgs (pipe_out, 0);
	}
	break;
    } /* switch */
  } /* while */
}

/* -------- Main -------- */

int main (int argc, char *argv[])
{
  int c = '?';

  prog = argv[0];

  opterr = 0;
  while ((c = getopt_long (argc, argv, short_options, 
                long_options, NULL)) != EOF) 
  {
    switch(c) 
    {
      case 'h': /* Print usage */
      case '?':
        usage(); 
	break;
      case 'n':
	opt_null = TRUE;
	break;
      case 'N':
	opt_nvdev = TRUE;
	break;
      case 'd':
        opt_debug = TRUE;
        break;
      case 'q':
        opt_quiet = TRUE;
        break;
    }
  }

  if (!opt_debug) {
     closelog (); /* Close any previous log. */
     openlog ("nvtvd", LOG_PID, LOG_USER);
     RAISE (MSG_INFO, "started");
  }

  unlink (PIPE_OUT);
  unlink (PIPE_IN);

  umask (0000); /* Reset umask */

  if (mkfifo (PIPE_OUT, 0622)) { /* rw--w--w- */
    unlink (PIPE_OUT);
    RAISE (MSG_ABORT, "Cannot create pipe %s", PIPE_OUT);
  }
  if (mkfifo (PIPE_IN, 0644)) { /* rw-r--r-- */
    unlink (PIPE_OUT);
    unlink (PIPE_IN);
    RAISE (MSG_ABORT, " Cannot create pipe %s", PIPE_IN);
  }

  RAISE (MSG_DEBUG, "pipes made");

  if (opt_null) {
    srv_root = back_null_init (); 
  } else {
    if (back_root_avail ()) {
      srv_root = back_root_init ();
    } else if (opt_nvdev && back_nvdev_avail (TRUE)) {
      srv_root = back_nvdev_init ();
    } else {
      RAISE (MSG_ABORT, "Cannot access video cards. Either you are not root,"
	       "or the NVidia devices\nare not accessible.");
    }
  }

  RAISE (MSG_DEBUG, "server loop");
  if (!opt_debug) {
     daemon(0,0);
     RAISE (MSG_INFO, "detached from terminal");
  }
  srv_loop ();

  fclose (pipe_in);
  fclose (pipe_out);
  unlink (PIPE_OUT);
  unlink (PIPE_IN);
  if (!opt_debug) {
    closelog (); 
  }

  return 0;
}

/* FIXME: Signals kill, hup */

