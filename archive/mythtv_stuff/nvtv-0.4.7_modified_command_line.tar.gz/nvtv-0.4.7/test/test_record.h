#ifndef _TEST_RECORD_H
#define _TEST_RECORD_H

#include "tester.h"

CARD32 recordRead  (int zone, CARD32 addr, BitSize bits, char* dir);
void recordWrite (int zone, CARD32 addr, CARD32 data, BitSize bits, char* dir);

CARD32 recordReadDirect (int zone, CARD32 addr, BitSize bits);

void recordPrint (char *title);

void configSetup (char *card, char *enc, char *head);

#endif /* _TEST_RECORD_H */
